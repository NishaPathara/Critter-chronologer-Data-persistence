package com.udacity.jdnd.course3.critter.schedule;

import com.udacity.jdnd.course3.critter.entities.Schedule;
import com.udacity.jdnd.course3.critter.pet.PetService;
import com.udacity.jdnd.course3.critter.user.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles web requests related to Schedules.
 */
@RestController
@RequestMapping("/schedule")
public class ScheduleController {
    @Autowired
    ScheduleService scheduleService;

    @Autowired
    UserService userService;

    @Autowired
    PetService petService;
    @PostMapping
    public ScheduleDTO createSchedule(@RequestBody ScheduleDTO scheduleDTO)
            throws UnsupportedOperationException {
        //get schedule if already exists otherwise create new
        Schedule schedule = scheduleService.findSchedule(scheduleDTO.getId()).orElseGet(Schedule::new);
        schedule.setDate(scheduleDTO.getDate());
        schedule.setActivities(scheduleDTO.getActivities());
        schedule.setEmployees(userService.findEmployees(scheduleDTO.getEmployeeIds()));
        schedule.setPets(petService.findPets(scheduleDTO.getPetIds()));
        schedule = scheduleService.save(schedule);

        return copyScheduleToDTO(schedule);
    }

    @GetMapping
    public List<ScheduleDTO> getAllSchedules() {
        List<Schedule> schedules = scheduleService.findAllSchedules();
        return schedules.stream().map(this::copyScheduleToDTO).collect(Collectors.toList());
    }

    @GetMapping("/pet/{petId}")
    public List<ScheduleDTO> getScheduleForPet(@PathVariable long petId) throws UnsupportedOperationException{
        List<Schedule> schedules = scheduleService.findSchedulesForPet(petId);
        return schedules.stream().map(this::copyScheduleToDTO).collect(Collectors.toList());
    }

    @GetMapping("/employee/{employeeId}")
    public List<ScheduleDTO> getScheduleForEmployee(@PathVariable long employeeId) throws UnsupportedOperationException {
        List<Schedule> schedules = scheduleService.findSchedulesForEmployee(employeeId);
        return schedules.stream().map(this::copyScheduleToDTO).collect(Collectors.toList());
    }

    @GetMapping("/customer/{customerId}")
    public List<ScheduleDTO> getScheduleForCustomer(@PathVariable long customerId) throws UnsupportedOperationException {
        List<Schedule> schedules = scheduleService.findSchedulesForCustomer(customerId);
        return schedules.stream().map(this::copyScheduleToDTO).collect(Collectors.toList());
    }

    private ScheduleDTO copyScheduleToDTO(Schedule schedule) {
        ScheduleDTO schedule_dto = new ScheduleDTO();
        BeanUtils.copyProperties(schedule, schedule_dto);
        schedule.getEmployees().forEach(employee -> {schedule_dto.getEmployeeIds().add(employee.getId());});
        schedule.getPets().forEach(pet -> {schedule_dto.getPetIds().add(pet.getId());});
        return schedule_dto;
    }
}
