package com.udacity.jdnd.course3.critter;

public class Views {
    public static class Public {}
    public static class Internal extends Public {
    }
}
