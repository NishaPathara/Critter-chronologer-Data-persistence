package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.entities.Customer;
import com.udacity.jdnd.course3.critter.entities.Employee;
import com.udacity.jdnd.course3.critter.entities.EmployeeSkill;
import com.udacity.jdnd.course3.critter.entities.Pet;
import com.udacity.jdnd.course3.critter.pet.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    PetRepository petRepository;

    public Optional<Customer> findCustomer(Long id) {
        return customerRepository.findById(id);
    }
    public Optional<Employee> findEmployee(Long id) {
        return employeeRepository.findById(id);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
    public List<Employee> findEmployees() {
        return employeeRepository.findAll();
    }
    public List<Employee> findEmployees(List<Long> employeeIds) {
        List<Employee> employees = employeeRepository.findAllById(employeeIds);
        return employees;
    }
    @Transactional
    public Customer save(Customer customer, List<Long> petIds) {
        if (petIds != null && !petIds.isEmpty()) {
            for (Long petId : petIds) {
                Pet pet = petRepository.findById(petId).orElseThrow(() -> new UnsupportedOperationException());
                customer.getPets().add(pet);
            }
        }
        return customerRepository.save(customer);
    }
    //save employee
    @Transactional
    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Employee> findAvailableEmployees(Set<EmployeeSkill> skills, LocalDate date) {
        List<Employee> employees = employeeRepository
                .getAllByDaysAvailableContains(date.getDayOfWeek()).stream()
                .filter(employee -> employee.getSkills().containsAll(skills))
                .collect(Collectors.toList());
        return employees;
    }


}