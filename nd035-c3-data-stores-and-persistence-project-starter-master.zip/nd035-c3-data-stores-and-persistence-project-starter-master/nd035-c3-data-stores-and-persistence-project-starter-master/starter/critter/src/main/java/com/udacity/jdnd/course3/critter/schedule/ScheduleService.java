package com.udacity.jdnd.course3.critter.schedule;

import com.udacity.jdnd.course3.critter.entities.Customer;
import com.udacity.jdnd.course3.critter.entities.Employee;
import com.udacity.jdnd.course3.critter.entities.Pet;
import com.udacity.jdnd.course3.critter.entities.Schedule;
import com.udacity.jdnd.course3.critter.pet.PetRepository;
import com.udacity.jdnd.course3.critter.pet.PetService;
import com.udacity.jdnd.course3.critter.user.CustomerRepository;
import com.udacity.jdnd.course3.critter.user.EmployeeRepository;
import com.udacity.jdnd.course3.critter.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class ScheduleService {
    @Autowired
    ScheduleRepository scheduleRepository;
    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    PetRepository petRepository;

    //find schedule with id
    public Optional<Schedule> findSchedule(Long id) {
        return scheduleRepository.findById(id);
    }

    //find all schedules
    public List<Schedule> findAllSchedules() {
        return scheduleRepository.findAll();
    }

    // save the schedule to employees and pets
    @Transactional
    public Schedule save(Schedule schedule) {
        schedule = scheduleRepository.save(schedule);

        for (Employee employee : schedule.getEmployees()){
            employee.getSchedules().add(schedule);
            employeeRepository.save(employee);
        }
        for (Pet pet : schedule.getPets()) {
            pet.getSchedules().add(schedule);
            petRepository.save(pet);
        }
        return schedule;
    }
    //find schedules for employeeid
    public List<Schedule> findSchedulesForEmployee(long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow(() -> new UnsupportedOperationException());
        return employee.getSchedules();
    }
    //find schedules for petid
    public List<Schedule> findSchedulesForPet(long petId) {
        Pet pet = petRepository.findById(petId).orElseThrow(() -> new UnsupportedOperationException());
        return pet.getSchedules();
    }
    //find schedule for pet owner
    public List<Schedule> findSchedulesForCustomer(long customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new UnsupportedOperationException());
        List<Schedule> customerSchedules = customer.getPets()
                .stream()
                .map(Pet::getSchedules)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
        return customerSchedules;
    }
}
