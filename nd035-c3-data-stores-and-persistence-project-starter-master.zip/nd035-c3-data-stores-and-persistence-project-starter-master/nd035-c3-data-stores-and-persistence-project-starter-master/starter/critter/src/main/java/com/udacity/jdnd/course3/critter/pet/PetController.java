package com.udacity.jdnd.course3.critter.pet;

import com.udacity.jdnd.course3.critter.entities.Pet;
import com.udacity.jdnd.course3.critter.user.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Handles web requests related to Pets.
 */
@RestController
@RequestMapping("/pet")
public class PetController {
    @Autowired
    PetService petService;
    @PostMapping
    public PetDTO savePet(@RequestBody PetDTO petDTO)  {
        // get petid,and get pet if it already exists otherwise create new
        long petId = petDTO.getId();
        Pet pet = petService.findPet(Long.valueOf(petId)).orElseGet(Pet::new);

        // copy user input to pet ignoring id field
        BeanUtils.copyProperties(petDTO, pet, new String[] { "id"} );

        // save the pet to the owner.
        pet = petService.save(pet, petDTO.getOwnerId());

        // return the updated DTO
        PetDTO updatedDTO = new PetDTO();
        BeanUtils.copyProperties(pet, updatedDTO);
       // updatedDTO.setOwnerId(pet.getOwner().getId());
        return updatedDTO;
    }
    @GetMapping("/{petId}")
    public PetDTO getPet(@PathVariable long petId)  {
        //get pet with petid and copy to petdto
        PetDTO pet_dto = new PetDTO();
        Pet pet = petService.findPet(petId).orElseThrow(() -> new UnsupportedOperationException());
        BeanUtils.copyProperties(pet, pet_dto);
        pet_dto.setOwnerId(pet.getOwner().getId());
        return pet_dto;
    }

    @GetMapping
    public List<PetDTO> getPets(){
        //get all pets and copy to dto for each
        List<Pet> pets = petService.findAllPets();
        return pets.stream().map(this::copyPetDTO).collect(Collectors.toList());
    }

    @GetMapping("/owner/{ownerId}")
    public List<PetDTO> getPetsByOwner(@PathVariable long ownerId) {
        //get all pets for an owner and copyto dto for each
        List<Pet> pets = petService.findPetByOwner(Long.valueOf(ownerId));
        return pets.stream().map(this::copyPetDTO).collect(Collectors.toList());
    }
    private PetDTO copyPetDTO(Pet pet) {
        PetDTO petDTO = new PetDTO();
        petDTO.setId(pet.getId().longValue());
        petDTO.setName(pet.getName());
        petDTO.setType(pet.getType());
        petDTO.setOwnerId(pet.getOwner().getId().longValue());
        petDTO.setBirthDate(pet.getBirthDate());
        petDTO.setNotes(pet.getNotes());
        return petDTO;
    }
}
