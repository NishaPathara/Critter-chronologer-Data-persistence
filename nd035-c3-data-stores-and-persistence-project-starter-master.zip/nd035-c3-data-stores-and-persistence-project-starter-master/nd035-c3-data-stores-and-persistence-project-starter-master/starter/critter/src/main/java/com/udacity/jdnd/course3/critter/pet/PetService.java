package com.udacity.jdnd.course3.critter.pet;

import com.udacity.jdnd.course3.critter.entities.Customer;
import com.udacity.jdnd.course3.critter.entities.Pet;
import com.udacity.jdnd.course3.critter.user.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class PetService {

    @Autowired
    PetRepository petRepository;
    @Autowired
    CustomerRepository customerRepository;

    //find a pet with petid
    public Optional<Pet> findPet(Long id) {
        return petRepository.findById(id);
    }

    //find all pets
    public List<Pet> findAllPets() {
        return petRepository.findAll();
    }

    //find all pets with given petids
    public List<Pet> findPets(List<Long> petIds) {
        List<Pet> pets = petRepository.findAllById(petIds);
        return pets;
    }

    //find pet owner for an ownerid
    public List<Pet> findPetByOwner(Long ownerId) {
        return petRepository.findByOwnerId(ownerId);
    }

    //save pet
    @Transactional
    public Pet save(Pet pet, Long ownerId)  {
        // find teh owner
        Customer owner = customerRepository.findById(ownerId).orElseThrow(() -> new UnsupportedOperationException());
        // add the owner to the pet
        pet.setOwner(owner);
        pet = petRepository.save(pet);
        // update the owner with the new pet
        owner.getPets().add(pet);
        customerRepository.save(owner);
        return pet;
    }
}
